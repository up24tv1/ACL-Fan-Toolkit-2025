# Credits & Sources

The information contained in this toolkit is curated from official and authoritative sources. Where possible, we provide direct citations with line references. Please consult the original resources for the most up‑to‑date details.

## Festival Dates & Schedule

* **2025 Festival Dates:** The Austin City Limits Music Festival is scheduled for **October 3–5 (Weekend One) and October 10–12 (Weekend Two)**. This is confirmed on the official schedule page【739485913955787†L34-L52】.

## Bag Policy

* **Bag Sizes & Clear Bags:** The official ACL bag policy permits small clutches and fanny packs up to **6" × 9"** without needing to be clear and allows other bags up to **12" × 6" × 12"** provided they are clear【320542959037575†L15-L25】. Small hydration packs with up to two extra pockets are also allowed【320542959037575†L23-L25】.

* **Allowed & Prohibited Items:** The allowed and prohibited items list (portable battery packs, non‑aerosol sunscreen, chairs, blankets, etc.) is summarised from the FAQ【165265700682084†L20-L44】. Prohibited items include umbrellas, outside food and beverages, professional video equipment, drones and more【165265700682084†L58-L89】.

## Transportation & Getting to the Festival

* **No Parking at Zilker Park:** There is no onsite parking at the festival. Visitors are encouraged to take advantage of shuttles, rideshares, public transport or biking【899019454843021†L38-L94】.

* **Shuttle & Rideshare:** Festival shuttles depart from **Sand Beach Park** and drop off just outside the Barton Springs West entrance【899019454843021†L75-L79】. Rideshare apps like Lyft suggest using “Austin City Limits Music Festival” or “Zilker Park” as the destination【899019454843021†L46-L49】.

* **Bike/Scooter Parking:** Bike parking is available on **Stratford Drive** and **Azie Morton Road**. Additional bike and scooter parking is provided on **Toomey Road** and **Sterzing Street**【899019454843021†L91-L94】.

## Weather & Clothing

* **Average Temperatures:** In October, Austin experiences an average high temperature of **78.8 °F (26 °C)** and a low of **61 °F (16.1 °C)**【385536763830029†L72-L78】. Days are generally pleasantly warm, and nights are cooler.

* **UV Index:** The average daily maximum UV index in October is **5**, which indicates a moderate risk for UV exposure【385536763830029†L104-L109】. Sun protection (hat, sunscreen) is recommended.

* **Rainfall:** October typically sees around **2.56" (65 mm)** of precipitation over **10.9 days**【385536763830029†L83-L87】. While heavy rain is not common, it’s wise to have a lightweight rain layer.

## Food & Beverage Prices

* Food vendors at ACL Eats offer meals in the **$8–$24** range. For example, bagel sandwiches at Nervous Charlie’s cost **$12**【784391616744076†L147-L150】, carnitas tostadas at Con Todo are **$16**【784391616744076†L154-L158】, barbecue crunchwraps range from **$13 (half) to $24 (whole)**【784391616744076†L160-L166】, Sonoran hot dogs are **$15**【784391616744076†L219-L221】, and desserts like pancakes or ice cream are **$10–$12**【784391616744076†L174-L180】【784391616744076†L292-L294】.

## Weather & Safety Tips

* **UV Protection:** A moderate UV index of 5 means you can get sunburned without protection. Wear sunscreen, a hat and sunglasses, and seek shade during peak afternoon hours【385536763830029†L104-L114】.

* **Hydration:** Water stations are available inside the festival grounds. Bring an empty reusable bottle (non‑metal or plastic) to refill【165265700682084†L20-L39】.

## Local Insights & Activities

* **Photo Spots:** Popular photo locations include the Zilker Park hilltop for skyline shots, Barton Springs pool, the vibrant murals along South Congress Avenue, and sunset views over the Colorado River (Lady Bird Lake). While not all of these are officially cited, they are well‑known landmarks among locals and provide iconic Austin backdrops.

---

All research data is current as of September 18, 2025 (Central Time) and will be updated as official sources release new information. Always check the festival’s official website and FAQs 24–48 hours before attending for any last‑minute changes.