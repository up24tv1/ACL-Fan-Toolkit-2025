# Image Mockups Plan

When listing the ATX Festival Ultimate Fan Toolkit on Etsy or Gumroad, use high‑quality mockups to showcase the value of the bundle. Below is a suggested storyboard for six images; adjust as needed.

1. **Hero Image** – A flat‑lay or hand‑held smartphone displaying the Smart Calendar interface with colourful event cards. Add a caption overlay: “Plan Your Perfect ACL Weekend.” Keep plenty of negative space for legibility.

2. **Template Collage** – A montage of several Instagram Story templates, feed posts and reel covers fanned out. Highlight the vibrant colour palette and Austin motifs. Add a small note: “12 Stories • 6 Posts • 4 Covers.”

3. **Guide Preview** – Show 2–3 pages of the Festival Survival Guide (packing checklist, outfit planner, veteran tips). Use perspective mockups (e.g., pages open on a tablet or printed pages on a desk) to emphasise quality.

4. **Before & After Preset** – Place an unedited festival photo next to the same photo edited with one of the presets (e.g., Zilker Golden Hour). Overlay text: “Transform Your Photos.”

5. **Group Planning Kit** – Display the Group Planner form, invite card and budget calculator side‑by‑side. Include a caption like “Plan With Friends – Everything You Need.”

6. **All‑In‑One Bundle** – A styled layout of all digital assets: a laptop showing the calendar, printed guides, a phone with a social template, and overlay text listing all bundle components. Use the ATX colour palette to tie the scene together.

These mockups can be created using free tools like Canva or Photopea. For each image, ensure the visuals are high resolution and match the overall aesthetic of the toolkit.