# ATX Festival Ultimate Fan Toolkit – Start Here

Welcome to the **ATX Festival Ultimate Fan Toolkit (2025 Edition)**! This bundle is designed to help you plan, share and celebrate your Austin festival experience with ease. All of the files in this zip are organized by folder. Follow the instructions below to get started.

## 1. Smart Calendar

The heart of this toolkit is an **interactive smart calendar** that lets you browse the 2025 schedule, build your personal itinerary, check for conflicts, insert hydration breaks and export everything to your favourite calendar app.

1. Open the file at `Smart-Calendar/index.html` in any modern web browser (mobile or desktop). You don’t need an internet connection—everything runs locally.
2. Use the category filters to show or hide Music, Food & Drink, Meetups & Parties and Other events.
3. Click an event to view more details and add it to **My Plan**. Conflicts are flagged automatically.
4. Use the buttons in the sidebar to export your plan as an `.ics` calendar file, add hydration reminders, or clear your plan. Your selections are saved to your device.
5. This tool is for **personal use only**. It is **not affiliated with or endorsed by Austin City Limits®**.

## 2. Festival Survival Guide

In the `Festival-Survival-Guide.pdf` you’ll find:

* A printable and fillable **packing checklist** with weather toggles (hot/day, cool/night, rain plan).
* A **daily schedule template** to plan your must‑see artists, meal breaks and commute buffers.
* A **weather‑based outfit planner** tailored to October in Austin, with sun/UV tips and day‑to‑night layering advice.
* Quick‑reference **bag policies** and prohibited items from the official FAQ【320542959037575†L20-L35】.
* **Transportation hacks** including shuttle locations, bike/scooter parking and rideshare drop‑off zones【899019454843021†L38-L94】.
* A **food & water strategy** based on real prices at ACL Eats (expect $8–$24 per meal【784391616744076†L140-L181】) and tips for staying hydrated.
* A page of **veteran tips** compiled from festival veterans (arrive early for the best stage spots, pack earplugs, bring a small power bank, etc.).

## 3. Social Content Pack

Open the `Social-Templates` folder to find high‑resolution PNG templates for Instagram Stories, Feed posts and Reel covers. Editable Canva links are provided in `Social-Templates/Canva-Editable-Links.txt`. Each template uses the official colour palette and includes prompts for recap grids, outfit checks, artist reactions, food finds and more.

## 4. Photo Presets

The `Photo-Presets` folder contains four Lightroom preset files (`.dng` for mobile and `.xmp` for desktop) with instructions in `Preset-Install-Guide.pdf` and a table of settings in `Preset-Settings-Table.pdf`. Use these to give your festival photos a cohesive look—warm sunsets, neon nights and soft film grain.

## 5. Planning Kit

Use the `Planning-Kit` folder to coordinate with friends:

* A **fillable group planner** for who’s bringing what, meet times and backup spots.
* **Invite templates** for pre‑parties and after‑parties with QR placeholders for RSVP links.
* A **contact QR template** to share your socials or phone number quickly.
* A **budget calculator** to split costs and track expenses (also includes an optional Google Sheets link).

## 6. Influencer Variants

If you’re an influencer or collaborating with one, the `Influencer-Variants` folder contains YAML and CSV files to generate co‑branded assets. Each influencer gets unique discount codes, accent colours and pre‑written scripts for Stories and Reels.

## 7. Listings

The `Listings` folder holds ready‑to‑use copy for Etsy and Gumroad listings, along with a mockup plan for product photos. You can customise the pricing and coupon codes before publishing.

## 8. Credits & Sources

Please see `CREDITS-SOURCES.md` for a list of all research sources, citations, and links used to compile the guide.

## Disclaimer

This toolkit is an unofficial fan‑made resource. It is **not affiliated with or endorsed by Austin City Limits®**. All trademarks, service marks, and company names are the property of their respective owners.