# Changelog – ATX Festival Ultimate Fan Toolkit

## v1.0 (ACL‑2025 Release)

Initial release of the ATX Festival Ultimate Fan Toolkit, designed for the 2025 Austin festival season.

### Added

* **Smart Calendar** – Interactive HTML schedule with category filters, event details modal, My Plan list, conflict detection, hydration breaks, .ics export, dynamic greeting and Font Awesome category icons.
* **Survival Guide** – 10‑page PDF including packing checklist, daily schedule template, outfit planner, bag policy summary, transportation tips, food budgeting, veteran advice and blank printable schedule page.
* **Social Content Pack** – 12 Instagram Story templates, 6 feed posts and 4 reel cover PNGs in 1080×1920 or 1080×1080 resolutions, matching the ATX colour palette.
* **Photo Preset Collection** – Four preset settings tables with dummy .DNG and .XMP files, install guide and quick‑tweak notes.
* **Planning Kit** – Group planner PDF, budget calculator PDF, four invite template designs (story & square), contact QR template PNG and QR placeholder.
* **Influencer Assets** – YAML configuration with discount codes, UTM links, accent colours and promotional scripts for five Austin influencers; CSV coupon table.
* **Listings Package** – Etsy and Gumroad listing copy (title, tags, meta, long descriptions), image mockup storyboard and pricing/coupon guidance.
* **Documentation** – README with usage instructions, Product Brief summarising research and audience, Guide Content summary, QA report and credits with citations.

### Known Limitations

* The provided .DNG files are placeholders; users must create their own Lightroom presets using the included settings.
* Group planner and budget PDFs are not fillable; they are printable forms.
* Canva links are placeholders; sellers must upload PNGs into Canva to create editable projects.

Future updates will aim to address these limitations and refine the toolkit based on user feedback.