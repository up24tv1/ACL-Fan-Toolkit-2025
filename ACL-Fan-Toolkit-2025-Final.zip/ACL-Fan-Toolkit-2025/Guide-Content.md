# Guide Content Summary

This document outlines the text and structure used in the **Festival Survival Guide** and related templates included in the toolkit. It is provided for reference if you wish to translate, update or repurpose any sections.

## Survival Guide (PDF)

1. **Title Page** – Displays the toolkit name and edition year. Sets the mood with the ATX colour palette.

2. **Packing Checklist** – Divided into essentials for hot days, cool nights and rainy weather. Items include:
   * Sun protection (hat, sunglasses, SPF 50+ sunscreen)
   * Earplugs
   * Portable charger and cables
   * Reusable water bottle (empty on entry)
   * Bandana or face mask
   * Light jacket or poncho for evenings / rain
   * Comfortable shoes (closed‑toe recommended)
   * Festival ticket/wristband
   * ID and payment cards
   * Cash for tips or small vendors
   * Blanket or small chair (permitted style)

3. **Daily Schedule Template** – Blank planner with columns for time, artist, stage, food/water reminders and notes. Includes space for “Top 3 Must‑See Acts” each day and a commuter buffer for leaving/arriving.

4. **Weather‑Based Outfit Planner** – Matrix with rows for temperature ranges (95 °F+, 80–95 °F, 60–80 °F) and columns for clothing suggestions (tops, bottoms, footwear, accessories). Encourages layering for day‑to‑night transitions.

5. **Bag Policy & Rules** – Summarises allowed bag sizes, hydration packs and lists of prohibited items as per ACL FAQs【320542959037575†L15-L25】【165265700682084†L58-L89】. Reminds users to check official site 24–48 hours before the festival for updates.

6. **Transportation Hacks** – Bullet list of shuttle departure points, bike/scooter parking locations, rideshare drop‑off tips and a warning about the lack of onsite parking【899019454843021†L38-L94】. Encourages using public transport or walking from nearby hotels.

7. **Food & Water Strategy** – Suggestions on budgeting for meals ($8–$24 per meal【784391616744076†L147-L150】【784391616744076†L160-L166】), identifying refill points for water bottles, and pacing food intake throughout the day. Includes a mini table to log daily food & beverage expenses.

8. **Veteran Tips** – Insider advice such as: arrive early for front‑row spots, familiarise yourself with stage locations, bring a fully charged power bank, download the festival map to your phone, and respect your fellow attendees. Also reminds to designate a meetup point if cell service drops.

## Daily Schedule (Printable Page)

The standalone **Daily Schedule Template** PDF repeats the blank schedule from the guide for those who prefer a separate sheet for each day. It uses the same headings: Time, Artist, Stage, Food/Water, Notes, and Top 3 Acts.

## Social Templates Text Overlays

Each social template includes placeholder text prompts such as:

* **Day 1 Arrival:** “Day 1 – We’re here! 🙌”
* **Fit Check:** “Today’s fit: …”
* **Artist Reactions:** “Best part of today’s sets: …”
* **Food Finds:** “Taco count: …”
* **Squad Photos:** “Festival fam 💕”
* **Sunset Shots:** “Golden hour magic”
* **Top 3 Sets:** “Can’t miss: …”
* **Afterparty Tease:** “Afterparty @ … (Scan QR)”
* **Map Teaser:** “Where to next?”
* **Rain Plan:** “Rain or shine, we’re ready ☔”
* **What I Packed:** “My must‑haves: …”
* **Day 3 Recap:** “Weekend memories (swipe) ➡️”

Feed posts include headings like “Weekend Recap,” “Quote of the Day,” “Checklist Share,” “Budget Snapshot,” “Best Bites” and “Top 5 Moments.” Reel covers are labelled “ATX Day 1,” “Neon Nights,” “Sunset Set” and “Afterparty Recap.”

## Group Planner & Budget Templates

The **Group Planner** contains blank fields for names and items to bring, a schedule grid for each day’s meetup times and locations, and a box for a backup meeting spot. The **Budget Calculator** table has columns for expense item, amount, paid by and notes, with ten rows for entries. Both forms include brief instructions and use the toolkit colour palette.

## Preset Quick‑Tweak Notes

* **Zilker Golden Hour** – Increase temperature and vibrance; works best on sunset photos. Adjust shadows if faces are too dark.
* **Austin Neon Nights** – Boost contrast and clarity; reduce highlights for stage lights. Use noise reduction as needed.
* **Festival Film** – Adds warm tint and grain; adjust exposure down if images look washed out.
* **Desert Bloom** – Emphasises greens and teals; protect skin tones by adjusting orange saturation and luminance.

These notes are repeated in the Preset Install Guide for quick reference.