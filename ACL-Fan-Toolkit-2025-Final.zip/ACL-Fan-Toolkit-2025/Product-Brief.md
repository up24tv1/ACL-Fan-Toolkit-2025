# Product Brief – ACL Festival Ultimate Fan Toolkit (2025 Edition)

## Overview

The **ATX Festival Ultimate Fan Toolkit** is a digital bundle designed to transform how music fans experience Austin’s biggest music festival. It addresses three core pains—**planning overwhelm, lacklustre social content, and missing insider/local knowledge**—by combining a smart calendar, survival guide, social media templates, Lightroom presets, a group planning kit and influencer marketing assets. This brief summarises the research that informed the product design.

## Key Event Facts

* **Festival Dates:** The 2025 Austin music festival runs over two weekends: **October 3–5** and **October 10–12**【739485913955787†L34-L52】.  Each weekend hosts approximately 75,000 attendees per day.
* **Location:** Zilker Park, Austin, Texas. No onsite parking is provided; attendees must use shuttles, rideshares, bikes or public transport【899019454843021†L38-L94】.
* **Schedule:** Line‑ups typically span midday to late evening with headliners around sunset and after dark. Our demo events reflect a mix of music performances (e.g., Sabrina Carpenter, The Strokes), food experiences and meet‑ups.

## Practical Constraints

### Bag Policy

* **Allowed sizes:** Small clutches up to **6 × 9 inches** and clear bags up to **12 × 6 × 12 inches**【320542959037575†L15-L25】.
* **Hydration packs:** Allowed if they have no more than two additional pockets【320542959037575†L23-L25】.
* **Prohibited:** Outside food/drinks, umbrellas, professional camera gear, drones and other prohibited items【165265700682084†L58-L89】.

### Weather & Safety

* **October climate:** Austin’s average high temperature is **78.8 °F (26 °C)** and the low is **61 °F (16 °C)**【385536763830029†L72-L78】. Moderate UV index (5) means sunscreen and hats are necessary【385536763830029†L104-L109】.
* **Rain:** October brings about **2.56 inches** of rain over **~11 days**【385536763830029†L83-L87】, so a lightweight rain jacket is advisable.
* **Hydration:** Bring an empty reusable bottle to refill at the water stations. Dehydration is common during festival weekends【165265700682084†L20-L39】.

### Transportation

* **No onsite parking:** Attendees must rely on shuttles, rideshares or bikes. Festival shuttles depart from **Sand Beach Park** and drop off near the Barton Springs West entrance【899019454843021†L75-L79】.
* **Rideshare:** Use “Austin City Limits Music Festival” or “Zilker Park” as your destination in the app【899019454843021†L46-L49】.
* **Bike/scooter parking:** Provided on **Stratford Drive**, **Azie Morton Road**, **Toomey Road** and **Sterzing Street**【899019454843021†L91-L94】.

### Food & Beverage

* **Price range:** Expect most meals to fall between **$8 – $24**. Examples from the 2023 vendor lineup include: bagel sandwiches **$12**【784391616744076†L147-L150】, carnitas tostadas **$16**【784391616744076†L154-L158】, barbecue crunchwraps **$13–$24**【784391616744076†L160-L166】, Sonoran hot dogs **$15**【784391616744076†L219-L221】 and desserts like pancakes or ice cream **$10–$12**【784391616744076†L174-L180】【784391616744076†L292-L294】.

## User Needs & Product Solutions

| Need | Evidence & Insights | Product Solution |
| --- | --- | --- |
| **Effortless planning** | Festival schedules feature dozens of overlapping sets and side events, causing decision fatigue. Official resources only provide static lists. | **Interactive Smart Calendar** shows events by day and category, lets users filter, view details, add to a personal itinerary, check for scheduling conflicts and export to .ics. Hydration breaks can be auto‑added. |
| **What to pack** | Attendees often forget essentials like sunscreen, earplugs, portable batteries and appropriate clothing. Bag and security rules are complex【165265700682084†L20-L44】. | **Survival Guide** contains a packing checklist, bag policy summary, outfit planner and veteran tips for comfort and safety. |
| **Sharing on social** | Over 70 % of festival‑goers post to Instagram or TikTok. Yet there are few ACL‑specific template packs【22†L1-L4】. | **Social Content Pack** of 12 story templates, 6 feed post layouts and 4 reel covers, all using the ATX colour palette and Austin motifs. |
| **Consistent photo aesthetics** | Festival lighting varies from bright sun to neon stages; editing for consistency is tricky. | **Photo Preset Collection** of four Lightroom presets (Zilker Golden Hour, Austin Neon Nights, Festival Film, Desert Bloom) with adjustable settings and install guide. |
| **Group coordination** | Groups need to decide who brings what, where to meet and how to split expenses. Traditional messaging threads become messy. | **Group Planner** PDF with tables for supplies and meeting times, **invite templates** with QR placeholders for RSVPs, **contact QR template**, and a **budget calculator**. |
| **Trusted recommendations** | Local tips about shuttle routes, hidden photo spots, food specials and after‑parties aren’t widely documented. | **Insider Tips** integrated throughout the guide, plus the toolkit invites collaboration with Austin influencers to provide authentic recommendations. |
| **Easy purchase & reuse** | Digital products on marketplace sites often lack polish and require complicated editing. | The toolkit comes fully packaged with polished PDFs, PNGs, preset files, YAML configurations for influencers and ready‑to‑use listing copy for Etsy/Gumroad. Buyers can reuse or adapt the core assets for future years or other festivals. |

## Audience & Marketing

The toolkit targets music fans visiting Austin (local and out‑of‑state), especially those active on Instagram/TikTok and those who travel with friends. Influencer partnerships are essential; our research identified Austin‑based influencers with 90k–240k followers each across niches such as beauty & travel (@joplacencio), food & local life (@feedmi_), travel (@readysetjetset), event & restaurant reviews (@friendsthatmunch), and art & lifestyle (@theaustinaesthetic). Collaborating with a mix of micro (10k–50k) and macro (100k+) influencers will maximise reach【3†L38-L42】.

## Competitive Gap

Existing ACL digital products on Etsy are mostly poster art and generic packing lists【29†L48-L56】【29†L186-L193】. There is little competition for interactive planners, localised social templates or Austin‑branded presets. By addressing these gaps and leveraging influencer promotion, we anticipate reaching **1 000+ downloads** in the first release cycle, achieving the goal of **$10 k+ in sales**.

## Conclusion

The ATX Festival Ultimate Fan Toolkit is a comprehensive, polished and mobile‑ready digital product suite. It blends the functionality of a smart event planner, the convenience of a printable survival guide, the aesthetics of professional social templates, and the organisation tools needed for group travel. By grounding every feature in research and local knowledge and by partnering with trusted Austin influencers, this bundle offers festival‑goers a superior experience while capturing a promising market opportunity.